### 要求

[任务五十：微型调查问卷平台](http://ife.baidu.com/task/detail?taskId=50)


### 实现（Vue.js + Vuex + Vue Router）
