<template>
    <div transition="gui">
        <h1>404???????</h1>
        <a v-link="{ path:'/' }" class="btn btn-lg btn-primary">返回首页</a>
    </div>
</template>