<template>
    <div transition="gui">
        <h1>欢迎光临</h1>
        <p>
            <a v-link="{ path:'/new' }" class="btn btn-lg btn-primary">创建一个问卷</a>
        </p>
    </div>
</template>
<script>
</script>