# IFE-2016
repo of Baidu Institute of Front-End Technology 2016.


## Notice
 - 这里只有前三阶段的任务哦...
 - 第四阶段的任务项目基本都是功能比较完整的网站/第三方库，所以我单独开了新库，链接在下面：
 - Project50: [微型问卷调查平台-RIA](https://github.com/hellozts4120/Micro-Questionnaire-RIA)
 - Project51: [多功能相册-第三方库](https://github.com/hellozts4120/IfeAlbum)
 
 
## Undone
 - 部分任务没有做，一般是过于简单（刚开始的几个html/css任务）， 或者比较复杂，需要消耗太多时间（王牌特工系列）
 - 没有做（也不打算做）的任务有：`1, 2, 3, 4, 5, 6, 10, 11, 47, 48, 49, 52`