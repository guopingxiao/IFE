var common = {
    euclidean: function (x, y) {
        return Math.sqrt(x * x + y * y);
    }
};