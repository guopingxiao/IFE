# 问卷管理平台

### 特点：
- 纯js语法
- 用的本地储存为indexedDB
- 接入了echarts.js，美化了数据展示的样式

### 测试：
- 已用以下设备测试，均能正常运行。
- Iphone 6s plus 10.2.1版本的Safiri浏览器
- Oppo R9 自带的浏览器
- Chrome 57.0.2986.0 (64-bit)
- Firefox 51.0.1 (32 位)
- Microsoft Edge 38.14393.0.0
- IE10 IE11 （10以下不支持IndexedDB）
- 已完成媒介查询对移动端的适配