# 2016年百度IFE春季班
## Demo 
task13 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task13><br>
task13 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task13/>

task14 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task14><br>
task14 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task14/>

task15 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task15><br>
task15 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task15/>

task16 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task16><br>
task16 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task16/>

task17 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task17><br>
task17 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task17/>

task18 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task18><br>
task18 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task18/>

task19 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task19><br>
task19 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task19/>

task20 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task20><br>
task20 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task20/>

task21 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task21><br>
task21 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task21/>

task29 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task29><br>
task29 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task29/>

task30 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task30><br>
task30 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task30/>

task31 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task31><br>
task31 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task31/>

task32 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task32><br>
task32 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task32/>

task33 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task33><br>
task33 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task33/>

task34 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task34><br>
task34 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task34/>

task35 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task35><br>
task35 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task35/>

task36 任务要求地址：<https://github.com/pkjy/ife-task/tree/gh-pages/2016_spring/part2/task36><br>
task36 在线预览地址：<http://pkjy.github.io/ife-task/2016_spring/part2/task36/>
## IFE春季班第二阶段任务

　　第二阶段的主要目标是帮助大家 **了解、认识、学习、掌握JavaScript**。第一阶段任务从 **3月21日** 开始，持续到 **4月21日**。当然，您也可以在这个时间以后继续自行实践练习。第一阶段和第二阶段有一部分时间是重合的，主要考虑到大家的基础不同，有的同学HTML/CSS比较好，想更多地参与JavaScript的学习。对于想继续学习CSS的各位依然可以按照自己的节奏继续学习第一阶段的任务。

　　第二阶段任务一共有 **6** 个系列 **24** 个题目，如下：

> **任务十三**：面向零基础的JavaScript代码编写（一），难度简单。对JS、事件、DOM有个初体验

> **任务十四**：面向零基础的JavaScript代码编写（二），难度简单。对JS的判断、循环、数组等有个初体验

> **任务十五**：面向零基础的JavaScript代码编写（三），难度简单。继续熟悉JavaScript

> **任务十六**：面向零基础的JavaScript代码编写（四），难度中等。学习事件代理、表单验证等

> **任务十七**：面向零基础的JavaScript代码编写（五），难度中等。做一个较为完成的有JavaScript交互的页面

　

> **任务十八**：基础JavaScript练习（一），难度简单。实现一个基本队列的相关操作

> **任务十九**：基础JavaScript练习（二），难度简单。丰富队列操作，实现一个排序算法的可视化呈现

> **任务二十**：基础JavaScript练习（三），难度简单。实践字符串、数组相关方法

> **任务二十一**：基础JavaScript练习（四），难度简单。结合实际运用场景，综合练习十八到二十的学习内容

　


> **任务二十二**：JavaScript和树（一），难度简单。用JavaScript实践二叉树的遍历

> **任务二十三**：JavaScript和树（二），难度简单。用JavaScript实践多叉树的遍历

> **任务二十四**：JavaScript和树（三），难度中等。用JavaScript实践多叉树的节点相关操作

> **任务二十五**：JavaScript和树（四），难度中等。结合实际运用场景，综合练习二十二到二十四的学习内容

　

> **任务二十六**：行星与飞船（一），难度中等。学习面向对象编程及基础的设计模式，实现一个有行星和飞船的宇宙

> **任务二十七**：行星与飞船（二），难度中等。改善在任务二十六中创建的各个航空系统

> **任务二十八**：行星与飞船（三），难度中等。改善在任务二十七中创建的各个航空系统

　

> **任务二十九**：表单（一），难度简单。学习单个表单如何进行验证

> **任务三十**：表单（二），难度简单。学习一个完整表单如何进行验证

> **任务三十一**：表单（三），难度简单。学习如何实现联动表单

> **任务三十二**：表单（四），难度中等。学习如何实现一个表单工厂

　

> **任务三十三**：听指令的小方块（一），难度简单。实现一个通过文本指令运动的小方块

> **任务三十四**：听指令的小方块（二），难度简单。升级指令系统，实现动画运动效果

> **任务三十五**：听指令的小方块（三），难度中等。升级指令系统，允许输入一段指令集合

> **任务三十六**：听指令的小方块（四），难度高。提供墙的功能，实现寻路算法

　　同第一阶段一样，这二十四个任务**并非所有人都要去完成**，而是需要大家按照自己当前的能力水平来合理评估和选择。

　　从任务的难易程度排序，简单到困难，依次是：**任务13-17，18-21，22-25** | **29-32，26-28，33-36**

　　基础较好的同学可以直接选择难度较大的任务集合。能力较强的同学也可以在某个系列中直接选择靠后面较难的题目。
## notes

#### task14 零基础JavaScript编码（二）
原来array数组自带排序的方法，`sort()`！！！一定要好好学好基础,知道这个后一切都迎刃而解。


#### task15 零基础JavaScript编码（三）
排序之后切记要`return data`哦，找了一个多小时，原来是这里出问题了。

好像火狐浏览器不支持`innerText`，改用了`innerHTML`

#### task16 面向零基础的JavaScript代码编写（四）
数组使用`bracket`的记法就可以同时命名数组的属性和值了。

`for in`循环的使用，如何遍历对象的属性和值，[W3School的示例](http://www.w3school.com.cn/tiy/t.asp?f=js_object_for_in)。

注意`childNodes`的运用，同`getElementsByTagName`一样，获得的是数组，访问的时候记得添加`[]`

#### task17 零基础JavaScript编码（五）
注意先引入js文件容易造成`document.getElement`的方法取得`null`值而报错，建议把js放到`</body>`前面

用来累计的变量`result`最初声明的语法一定要放到`for-in`循环的体外

使用数组的`bracket`的时候记得要带上`""`，把参数当作字符串才能正确读取~例如`pageState["nowSelectCity"]`

巧用对象的`replace`方法，

#### task18 基础JavaScript练习（一）
可以参照`inserBefore()`方法，[链接](http://www.w3school.com.cn/jsref/met_node_insertbefore.asp)、`appendChild`方法，[链接](http://www.w3school.com.cn/jsref/met_node_appendchild.asp)等等。

首先创建元素(`createElement()`)，再创建文本节点(`createTextNode()`)，再调用元素的插入功能把文本节点插入。

#### task19 基础JavaScript练习（二）
啊啊，验证数字的时候，返回的`false`也能被当作值创建文本节点。就算设置`return false`还是会自动返回`undefined`，一样有内容在，所以在另一个函数体里面加了个判断，不是`false`才能进行。

声明对象，数组一定要放在循环体外，不然只记录最后一项。

#### task20 基础JavaScript练习（三）
正则+`split`方法(把字符串分割成字符串数组)。`\s+`过滤一个或多个空格，本打算挑出那些特殊符号来匹配的，也可以换个思路，匹配所有的数字英文符号文字的然后取反匹配就好了。`[^abc]`就是这个方括号，里面的`^`就是取反。

#### task21 基础JavaScript练习（四）
监控回车`onkeydown`，回车的`keyCode`是13,空格是32,逗号是188。逗号用188号来监控有小BUG，会遗留逗号在表格里(已经查明，是重置输入框的时间太慢，放到插入子节点之前重置输入框就好了。)

```
//trim删除左右两端的空格
function trim(str) {
    var regex1 = /^\s*/;
    var regex2 = /\s*$/;
    return (str.replace(regex1, "")).replace(regex2, "");
}
```
#### task26 行星与飞船（一）
我选择的是`canvas`来画整个背景，对`canvas`的掌握,包括画圆`arc()`的方法，动态绘图`moveTo()` 、`lineTo()`的方法。

用`parseInt()`强行把字符串转成整数，自动过滤掉非数字，`parseFloat()`类似。

`drawImage()`函数把图像画进去画布。`clearRect(x,y,width,height)`可以把指定坐标的指定矩形范围清空.

把绘制背景地图的用`save()`保存起来，然后开始飞船的绘制，绘制完成后`restore()`，就相当于刷新了整个画布。

`document.getElementsByName()`,通过Name属性来操作DOM，用的比较少，但是关键时候很有用。

>---
假设一个圆的圆心坐标是(a,b)，半径为r，
则圆上每个点的X坐标=a + Math.sin(2*Math.PI / 360) * r ；Y坐标=b + Math.cos(2*Math.PI / 360) * r ；
---

#### task29 表单（一）单个表单项的检验
用到JS的`charCodeAt()`方法，可以返回指定位置的字符的Unicode编码,根据返回的编码分开计算英文与非英文的字符长度,[W3School](http://www.w3school.com.cn/jsref/jsref_charCodeAt.asp)。注意其余`charAt()`方法的区别。

#### task30 表单（二）多个表单项的动态校验
`nextSibling`是操作节点的，`nextElementSibliing`是操作元素的！！要分清楚

用到正则的`test()`方法，可以通过查询正则表达式返回布尔值。`^1`代表以1开头，`[3|4|5|8]` 紧跟上面的1后面，可以是3或4或5或8的一个数字，`[0-9]`表示0-9中间的任何数字，可以是0或9 ，`\d{4,8}`这个\d跟[0-9]意思一样，都是0-9中间的数字。`{4,8}`表示匹配前面的最低4位数字最高8位数字。我就直接用`{8}`来限制位数，记得在最后添加$表示结束匹配，否则超出的位数也会匹配成功。

#### task31 表单（三）联动
主要考察`select`的掌握程度。`select`可以通过索引值获取当前选中的文本或值。以下是原生js方法，参考[链接](http://blog.sina.com.cn/s/blog_a73036570101e9ry.html)

```
var obj = document.getElementByIdx_xx_x('testSelect'); //定位id

var index = obj.selectedIndex; // 选中索引

var text = obj.options[index].text; // 选中文本

var value = obj.options[index].value; // 选中值
```

#### task32 表单（四）实现表单自动生成工厂
用`checkbox`的`checked`属性，被选中会返回`true`。这个主要考察面向对象编程和模块化。！

当变量名称和已经申明的对象名称重复了得时候，就不能调用对象了...解决方法，把对象们放到一个数组里，调用数组就好了~~

#### task33 听指令的小方块（一）
`border-collapse`属性设置表格的边框是否被合并为一个单一的边框，还是像在标准的 HTML 中那样分开显示。

#### task34 听指令的小方块（二）
两种调用`setTimeout`和`setInterval`都接收两个参数，第一个是函数或字符串。

#### task35 听指令的小方块（三）
CSS3的`resize`属性规定是否可由用户调整元素的尺寸。

实时显示行数可以通过获取相同`class`的个数来确定。匹配换行符的个数，来动态设置每行的行数。

`onscroll`事件元素滚动时执行。

`scrollTop`设置或获取位于对象最顶端和窗口中可见内容的最顶端之间的距离，把行数的的最顶端`margin`设置为相关`-`的像素就能做出滚动的效果。

看完《高程》的间歇调用和超时调用后，来修改这里用到的两种调用，书上是建议用超时内调用超时而不建议间歇调用。顺便把动作的逻辑改了一下，应该OK了暂时没发现BUG。