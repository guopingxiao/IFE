# ife-task

###### 2016年春季班：

1. [Part1 任务汇总](https://github.com/pkjy/ife-task/blob/gh-pages/2016_spring/part1/)
2. [Part2 任务汇总](https://github.com/pkjy/ife-task/blob/gh-pages/2016_spring/part2/)
3. [Part3 任务汇总](https://github.com/pkjy/ife-task/blob/gh-pages/2016_spring/part3/)
4. [Part4 任务汇总](https://github.com/pkjy/ife-task/blob/gh-pages/2016_spring/part4/)

###### 2015年春季班：

[task003](https://github.com/pkjy/ife-task/blob/gh-pages/2015_spring/task0003/)

