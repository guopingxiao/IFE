export const ALERT_DIALOG = "ALERT_DIALOG";
export const DISPLAY_DIALOG = "DISPLAY_DIALOG";
export const DRAG_DIALOG = "DRAG_DIALOG";
export const HIDE_DIALOG = "HIDE_DIALOG";
export const INIT_DIALOG = "INIT_DIALOG";