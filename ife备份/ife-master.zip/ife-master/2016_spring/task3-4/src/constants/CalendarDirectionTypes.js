export const LEFT = "LEFT";
export const RIGHT = "RIGHT";
export const IN = "IN";
export const OUT = "OUT";