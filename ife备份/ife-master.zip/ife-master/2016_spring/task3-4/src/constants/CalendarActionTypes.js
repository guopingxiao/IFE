export const SELECT = "SELECT";
export const SLIDE = "SLIDE";
export const ZOOM = "ZOOM";