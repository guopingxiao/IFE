export const RADIO = "单选";
export const CHECKBOX = "多选";
export const TEXT = "文本";